package application;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.RadioButton;
import javafx.scene.control.Spinner;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.cell.PropertyValueFactory;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javafx.application.Application;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

public class Login extends Application {
	Connection connection = null;
	Stage window;
	private TableView<Product> table = new TableView<>();
	private TableView<Product> tables = new TableView<>();
	  TableView<InCart> tablex = new TableView<>();
	  ObservableList<InCart> items = FXCollections.observableArrayList();
    private ObservableList<Product> data =FXCollections.observableArrayList();
    String cuid = "U8652";
	
	public static void main(String[] args) {
		launch(args);
	}
	 
	@Override
	public void start(Stage primaryStage) {
		try {
		    connection = DriverManager.getConnection("jdbc:mysql://localhost/cart", "root", "");
		} catch (SQLException e) {
			System.out.println("koneksi gagal");
		}

		//Setting Window
		window = primaryStage;
		window.setTitle("Login ");

	//Komponen Login Scene
		Label emailLabel = new Label("Email");
		TextField emailInput = new TextField("");
		Label passLabel = new Label("Password");
		TextField passInput= new TextField("");
		passInput.setPromptText("password");
		Button loginButton = new Button("Login");
		Button registerButton = new Button("Register");
		//Layouting
		HBox hbox = new HBox(10);
		hbox.setAlignment(Pos.BASELINE_RIGHT);
		hbox.getChildren().addAll(loginButton, registerButton);
		VBox vbox = new VBox(20);
		vbox.setPadding(new Insets(30));
		vbox.getChildren().addAll(emailLabel, emailInput, passLabel, passInput, hbox);
		//theScene
		Scene loginScene = new Scene(vbox, 300, 300);
		
		
	// Komponen Register Scene
		Label nameLabel = new Label("Name");
		TextField nameInput= new TextField("");
		nameInput.setPromptText("Name");
		Label usernameLabel = new Label("Username");
		TextField usernameInput= new TextField("");
		usernameInput.setPromptText("Username");
		Label passLabelR = new Label("Password");
		TextField passInputR= new TextField("");
		passInput.setPromptText("Confirm Password");
		Label cpassLabel = new Label("Confirm Password");
		TextField cpassInput= new TextField("");
		cpassInput.setPromptText("Confirm Password");
		Label emailLabelR = new Label("Email");
		TextField emailInputR= new TextField("");
		emailInput.setPromptText("xxxxxx@gmail.com");
		Label phoneLabel = new Label("Phone Number");
		TextField phoneInput= new TextField("");
		phoneInput.setPromptText("+62XXXXXXXXX ");
		Label genderLabel = new Label("Gender");
		//RadioButton
		ToggleGroup tg = new ToggleGroup(); 
		RadioButton rbm = new RadioButton("Male"); 
		RadioButton rbf = new RadioButton("Female"); 
		rbm.setToggleGroup(tg); 
	    rbf.setToggleGroup(tg); 
	    HBox hbo = new HBox(10);
		hbo.setAlignment(Pos.BASELINE_LEFT);
		hbo.getChildren().addAll( rbm, rbf);
		//checkbox
		CheckBox box = new CheckBox("I Agree with Terms And Condition");
		//Button
		Button loginButtonR = new Button("Login");
		Button registerButtonR = new Button("Register");
		//settingLayout
		HBox hboxR = new HBox(10);
		hboxR.setAlignment(Pos.BASELINE_RIGHT);
		hboxR.getChildren().addAll( registerButtonR, loginButtonR);
		VBox vboxR = new VBox(20);
		vboxR.setPadding(new Insets(30));
		vboxR.getChildren().addAll(nameLabel, nameInput, usernameLabel, usernameInput, passLabelR, passInputR, cpassLabel, cpassInput, emailLabelR, emailInputR, 
				phoneLabel, phoneInput, genderLabel,hbo, box, hboxR);
		//theScene
		Scene registerScene = new Scene(vboxR, 300, 700);
		
		
	//Komponen Main - Admin
		//layout
		BorderPane mainLayout = new BorderPane();
		//menu
		MenuBar menuBar = new MenuBar();
		//menubar component
		Menu menu = new Menu("Menu");
		Menu account = new Menu("Account");
		menuBar.getMenus().addAll(menu, account);
		//menuItem
		MenuItem manageProduct = new MenuItem("Manage Product");
		MenuItem logOut = new MenuItem("Log Out");
		menu.getItems().add(manageProduct); 
		account.getItems().add(logOut);
		//menambahkan tampilan 
		Label productListLabel = new Label("Manage Product");
		//table data
		refreshTable();
		//table
		TableColumn<Product, String> idCol = new TableColumn<>("ID");
        idCol.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getId()));

        TableColumn<Product, String> typeCol = new TableColumn<>("Type");
        typeCol.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getType()));

        TableColumn<Product, String> brandCol = new TableColumn<>("Brand");
        brandCol.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getBrand()));

        TableColumn<Product, String> priceCol = new TableColumn<>("Price");
        priceCol.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getPrice()));

        TableColumn<Product, String> stockCol = new TableColumn<>("Stock");
        stockCol.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getStock()));

        table.getColumns().addAll(idCol, typeCol, brandCol, priceCol, stockCol);
        table.setItems(data);
		
        //component in main
        Label productIdLabel = new Label("Product ID");
        TextField productIdInput= new TextField("");
        productIdInput.setPromptText("type id here to remove/update");
        Label productBrandLabel = new Label("Brand");
        TextField productBrandInput= new TextField("");
        Label priceSpinnerLabel = new Label("Price");
        Label stockSpinnerLabel = new Label("Stock");
        Spinner<Integer> priceSpinner = new Spinner<>(1000, 100000, 1000);
        Spinner<Integer> stockSpinner = new Spinner<>(30, 1000, 30);
        VBox priceBox = new VBox();
        VBox stockBox = new VBox();
        priceBox.getChildren().addAll(priceSpinnerLabel, priceSpinner);
        stockBox.getChildren().addAll(stockSpinnerLabel, stockSpinner);
        HBox spinnerBox = new HBox(20);
        spinnerBox.getChildren().addAll(priceBox,stockBox);
        //drop down menu
        ComboBox<String> comboBox = new ComboBox<>();
        Label typeLabel = new Label("Type");
        comboBox.getItems().addAll("Food", "Drink", "Sanitary");
        comboBox.setValue("Food");
        VBox typeBox = new VBox();
        typeBox.getChildren().addAll(typeLabel, comboBox);
        //button component
        Button insertProduct = new Button("Insert");
        Button updateProduct = new Button("Update");
        Button removeProduct = new Button("Remove");
        HBox adminButton = new HBox(20);
        adminButton.getChildren().addAll(insertProduct,updateProduct ,removeProduct);
        
        
		VBox adminView = new  VBox(20);
		adminView.getChildren().addAll(productListLabel,table, productIdLabel,productIdInput, productBrandLabel, productBrandInput,typeBox, spinnerBox,adminButton);
		mainLayout.setTop(menuBar);
		
		
		//adding all
		Scene mainScene = new Scene(mainLayout, 500, 700);
		
	//Komponen Main -User
		//layout
		BorderPane userLayout = new BorderPane();
		//menu
		MenuBar menuBarUser = new MenuBar();
		//menubar component
		Menu menuUser = new Menu("Menu");
		Menu accountUser = new Menu("Account");
		menuBarUser.getMenus().addAll(menuUser, accountUser);
		userLayout.setTop(menuBarUser);
		//menuItem
		MenuItem productList = new MenuItem("Product List");
		MenuItem cart = new MenuItem("Cart");
		MenuItem logOutUser = new MenuItem("Log Out");
		menuUser.getItems().addAll(productList,cart); 		 
		accountUser.getItems().add(logOutUser);
		//Komponen isi
		Label welcome = new Label("Welcome " + cuid);
		userLayout.setCenter(welcome);
		//adding all
		
		//Layout untuk ProductList
		VBox plBox = new VBox(10);
		Label title = new Label("Product List");
		
		Label pid = new Label("Product ID");
		TextField pidInput = new TextField();
		Label qty = new Label("Qty");
		Spinner<Integer> qtySpinner = new Spinner<>(1, 100000000,1);
		Button addCart = new Button("Add to Cart");
		tables.getColumns().addAll(idCol, typeCol, brandCol, priceCol, stockCol);
        tables.setItems(data);
		plBox.getChildren().addAll(title, tables, pid, pidInput, qty, qtySpinner, addCart);
		
		
		//Layout untuk Cart
		VBox cBox = new VBox(10);
		Label totalP = new Label("Total Price : " + getTotal(cuid));
		Label pidcL = new Label("Product ID");
		TextField  pidc = new TextField();
		Label qtycL = new Label("Qty");
		Spinner<Integer> qtyC= new Spinner<>(1, 100000000,1);
		Button removec = new Button("Remove from cart");
		Button checkout = new Button("Checkout");
		
		
		refreshTablex(cuid);
		//table 
        TableColumn<InCart, String> idCols = new TableColumn<>("Product ID");
        idCols.setCellValueFactory(new PropertyValueFactory<>("id"));

        TableColumn<InCart, String> brandCols = new TableColumn<>("Brand");
        brandCols.setCellValueFactory(new PropertyValueFactory<>("brand"));

        TableColumn<InCart, String> qtyCols = new TableColumn<>("Qty");
        qtyCols.setCellValueFactory(new PropertyValueFactory<>("qty"));

        TableColumn<InCart, String> priceCols = new TableColumn<>("Price");
        priceCols.setCellValueFactory(new PropertyValueFactory<>("price"));

        TableColumn<InCart, String> totalCol = new TableColumn<>("Total");
        totalCol.setCellValueFactory(new PropertyValueFactory<>("total"));

        tablex.getColumns().addAll(idCols, brandCols, qtyCols, priceCols, totalCol);
        tablex.setItems(items);
        cBox.getChildren().addAll(tablex, totalP, pidcL, pidc, qtycL, qtyC, removec, checkout);
		//adding all
        
		
		Scene userScene = new Scene(userLayout , 500, 700);
		
		
	//checkOut
		checkout.setOnAction(e ->{
			finalCheck(cuid);
			refreshTablex(cuid);
			window.show();
		});
		
	//deleteCart
		removec.setOnAction(e->{
			boolean check = true;
			if(pidc.getText().equals("")) {
				Alert.display("Warning", "must fill Product ID ");
				check = false;
			} else if(addedCart(cuid, pidc.getText()) == -1) {
				Alert.display("Warning", "Invalid Id");
				check = false;
			}
			
			if(check) {
				if(deleteCart(cuid, pidc.getText(), qtyC.getValue())) {
					refreshTablex(cuid);
					window.show();
				} else {
					Alert.display("Warning", "Not enaugh in cart");
				}
				
			}
		});
		
	//user-productList
		productList.setOnAction(e -> {
			refreshTable();
			userLayout.setCenter(plBox);
			window.show();
		});
		
	//user-cart
		cart.setOnAction(e -> {
			refreshTablex(cuid);
			userLayout.setCenter(cBox);
			window.show();
			
		});
	
	//addToCart
		addCart.setOnAction(e -> {
			boolean check = true;
			if(pidInput.getText().equals("")) {
				Alert.display("Warning", "must fill Product ID ");
				check = false;
			}if(!checkProductId(pidInput.getText())) {
				Alert.display("Warning", "Invalid ID");
				check = false;
			}
			
			//check if buy <= qty
			
			if(qtySpinner.getValue() > checkQty(pidInput.getText())) {
				Alert.display("Warning", "Not enaugh stock");
				check = false;
			} 
			
			//mulai untuk tambah ke cart
			int k = addedCart(cuid, pidInput.getText());
			if(k == -1) { //check if product don't exist in cart
				//adding new carts
				System.out.println(addedCart(cuid, pidInput.getText()));
				String sqlCart = "INSERT INTO `carts` (`userID`, `productID`, `qty`) VALUES ('"
						+ cuid
						+ "', '"
						+ pidInput.getText()
						+ "', '"
						+ qtySpinner.getValue()
						+ "')";
				
				if(inserdata(sqlCart)) {
					Alert.display("Warning", "Cannot Register due to system mistake");
				} else {
					pidInput.setText("");
					refreshTable();
					window.show();
				}
			} else { // product already exist in cart
				int newStocks = k + qtySpinner.getValue();
				String sqlCart = "UPDATE carts SET qty = '"
						+ newStocks
						+ "' WHERE userID = '"
						+ cuid
						+ "' AND productID = '"
						+ pidInput.getText()
						+ "'";
				
				if(inserdata(sqlCart)) {
					Alert.display("Warning", "Cannot Register due to system mistake");
				} else {
					
					refreshTable();
					window.show();
				}
			}
		});
		
	//admin-Product
		manageProduct.setOnAction(e -> {
			mainLayout.setCenter(adminView);
		});
		
	//admin-Insert Product
		insertProduct.setOnAction(e -> {
			boolean check = true;
			if(productBrandInput.getText().equals("")) {
				Alert.display("Warning", "must fill Brand ");
				check = false;
			} else if(productBrandInput.getText().length() <5 || productBrandInput.getText().length() > 20) {
				Alert.display("Warning", "must fill Brand ");
				check = false;
			}
			if(check) {
				
				String sql = "INSERT INTO `products` (`id`, `type`, `brand`, `price`, `stock`) VALUES ('"
						+ idGenProduct()
						+ "', '"
						+ comboBox.getValue()
						+ "', '"
						+ productBrandInput.getText()
						+ "', '"
						+ priceSpinner.getValue()
						+ "', '"
						+ stockSpinner.getValue()
						+ "')";
				if(inserdata(sql)) {
					Alert.display("Warning", "Cannot Register due to system mistake");
				} else {
					refreshTable();
					window.show();
				}
			}
			
		});
		
	//admin-Update Product
		updateProduct.setOnAction(e ->{
			boolean check = true;
			if(productIdInput.getText().equals("")) {
				Alert.display("Warning", "must fill ProductID ");
				check = false;
			}else if(!checkProductId(productBrandInput.getText())) {
				Alert.display("Warning", "Invalid ID");
				check = false;
			}
			else if(productBrandInput.getText().equals("")) {
				Alert.display("Warning", "must fill Brand ");
				check = false;
			} else if(productBrandInput.getText().length() <5 || productBrandInput.getText().length() > 20) {
				Alert.display("Warning", "Brand must have 5-20 character ");
				check = false;
			}
			if(check) {
				
				String sql = "UPDATE `products` SET `id` = '"
						+ productIdInput.getText()
						+ "', `type` = '"
						+ comboBox.getValue()
						+ "', `brand` = '"
						+ productBrandInput.getText()
						+ "', `price` = '"
						+ priceSpinner.getValue()
						+ "', `stock` = '"
						+ stockSpinner.getValue()
						+ "' WHERE `products`.`id` = '"
						+ productIdInput.getText()
						+ "'";
			
				if(inserdata(sql)) {
					Alert.display("Warning", "Cannot Register due to system mistake");
				} else {
					refreshTable();
					window.show();
				}
			}
		});
		
	//admin-Remove Product
		removeProduct.setOnAction(e -> {
			if(productIdInput.getText().equals("")) {
				Alert.display("Warning", "must fill ProductID ");
			}
			
			
			if(checkProductId(productIdInput.getText())) {
				deleteProduct(productIdInput.getText());
				refreshTable();
				window.show();
			} else {
				Alert.display("Warning", "invalid ProductID ");
			}
		});
		
	//berusaha untuk login // 
		loginButton.setOnAction(e -> {
			boolean checkEmail = false;
			boolean checkPass = false;
			String roles = "";
			try (Statement stmt = connection.createStatement();
					ResultSet rs = stmt.executeQuery("SELECT * FROM users")) {
				    while (rs.next()) {
				        String username = rs.getString("email");
				        String password = rs.getString("password");
				        String role = rs.getString("role");
				        String id = rs.getString("id");
				        if(username.equals(emailInput.getText())) {
				        	checkEmail = true;				        	
				        	if(password.equals(passInput.getText())) {
				        		checkPass = true;
				        		roles = role;
				        		cuid = id;
				        		break;
				        	} else {
				        		break;
				        	}
				        }
				    }
				} catch (SQLException a) {
			}
			
			if(checkEmail) {
				if(!checkPass) {
					Alert.display("Warning", "Password doesn't match ");
				}else {
					//berhasil nih
					emailInput.setText("");
					passInput.setText("");
					if(roles.equals("admin")) {
						window.setScene(mainScene);
						window.setTitle("Main Menu");
					} else {
						window.setScene(userScene);
						window.setTitle("Main Menu");
					}
				}
			} else {
				Alert.display("Warning", "Email doesn't exist!");
			}
		});
		
	//dari login page -> Register Page
		registerButton.setOnAction(e -> {
			window.setScene(registerScene);
			window.setTitle("Register");
		});
		
	//dari register page -> Login Page
		loginButtonR.setOnAction(e->{
			window.setScene(loginScene);
			window.setTitle("Login ");
		});
		
		
	//RegisterAkun
		registerButtonR.setOnAction(e ->{
			boolean check = true;
			
			String regex1 = "^[a-zA-Z0-9]+$";
			Pattern pattern1 = Pattern.compile(regex1);
			String regex2 = "^[+0-9]+$";
			Pattern pattern2 = Pattern.compile(regex2);
			
			String nama = nameInput.getText();
			String username = usernameInput.getText();
			String password = passInputR.getText();
			String cpassword = cpassInput.getText();
			String email = emailInputR.getText();
			String phone = phoneInput.getText();
			RadioButton rb = (RadioButton) tg.getSelectedToggle(); 
			
			Matcher matcher1 = pattern1.matcher(password);
			Matcher matcher2 = pattern2.matcher(phone);
			
			if(nama.length() <5 || nama.length() > 20) {
				Alert.display("Warning", "Name must be between 5-20 characters.");
				check = false;
			} else if(username.length() <3 || username.length() > 10) {
				Alert.display("Warning", "Username must be between 3-10 characters");
				check = false;
			} else if(!(matcher1.matches() && password.length() >=8)) {
				Alert.display("Warning", "Password must contain minimal 8 characters and alphanumeric.");
				check = false;
			} else if(!cpassword.equals(password)) {
				Alert.display("Warning", "Confirm Password must same as Password");
				check = false;
			} else if(testEmail(email)) {
				Alert.display("Warning", "Email must end with �@gmail.com�, contains 1 �@� and not in front, and unique.");
				check = false;
			} else if(phone.length() <=11 || !matcher2.matches() || !phone.startsWith("+62")) {
				Alert.display("Warning", "Phone Number must contain at least 10 characters, numeric, and starts with �+62�");
				check = false;
			} else if(rb == null) {
				Alert.display("Warning", "Gender must be choosed.");
				check = false;
			} else if(!box.isSelected()) {
				Alert.display("Warning", "CheckBox must be checked.");
				check = false;
			} 
			
			String gender = rb.getText();
			
			String id = idGen();
			
			String sql = "INSERT INTO `users` (`id`, `name`, `role`, `username`, `password`, `email`, `phoneNum`, `gender`) VALUES "
					+ "('"
					+ id
					+ "', '"
					+ nama
					+ "', '"
					+ "user"
					+ "', '"
					+ username
					+ "', '"
					+ password
					+ "', '"
					+ email
					+ "', '"
					+ phone
					+ "', '"
					+ gender
					+ "')";
			
			
			if(inserdata(sql)) {
				Alert.display("Warning", "Cannot Register due to system mistake");
			}
			
			if(check) {
				window.setScene(loginScene);
				window.setTitle("Login ");
			}
		});
		
	//Logout
		logOut.setOnAction(e ->{
			window.setScene(loginScene);
			window.setTitle("Login ");
		});
		logOutUser.setOnAction(e ->{
			window.setScene(loginScene);
			window.setTitle("Login ");
		});
		
		
		//-startpoint
		window.setScene(loginScene);
		window.show();
	}


	private void finalCheck(String cuid2) {
		Map<String, Integer> cart = new HashMap<>();
		try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/cart", "root", "");
		     PreparedStatement stmt = conn.prepareStatement("SELECT productID, qty FROM carts WHERE userID = ?")) {
		    stmt.setString(1, cuid2);
		    ResultSet rs = stmt.executeQuery();
		    while (rs.next()) {
		        String productID = rs.getString("productID");
		        int qty = rs.getInt("qty");
		        cart.put(productID, qty);
		    }
		} catch (SQLException e) {
		    // handle the exception
		}
		try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/cart", "root", "")) {
		    conn.setAutoCommit(false);
		    for (Map.Entry<String, Integer> entry : cart.entrySet()) {
		        String productID = entry.getKey();
		        int qty = entry.getValue();
		        String selectSQL = "SELECT stock FROM products WHERE id = ?";
		        PreparedStatement selectStmt = conn.prepareStatement(selectSQL);
		        selectStmt.setString(1, productID);
		        ResultSet rs = selectStmt.executeQuery();
		        if (rs.next()) {
		            int stock = rs.getInt("stock");
		            if (stock < qty) {
		                throw new SQLException("Stock is less than the required quantity");
		            }
		            String updateSQL = "UPDATE products SET stock = stock - ? WHERE id = ?";
		            PreparedStatement updateStmt = conn.prepareStatement(updateSQL);
		            updateStmt.setInt(1, qty);
		            updateStmt.setString(2, productID);
		            updateStmt.executeUpdate();
		        }
		    }
		    conn.commit();
		} catch (SQLException e) {
		    // handle the exception
		}
		
		try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/cart", "root", "");
		        PreparedStatement stmt = conn.prepareStatement("DELETE FROM carts WHERE userID = ?")) {
		    stmt.setString(1, cuid2);
		    stmt.executeUpdate();
		} catch (SQLException e) {
		    // handle the exception
		}
	}

	private int addedCart(String cuid2, String pid) {
		try {
		    connection = DriverManager.getConnection("jdbc:mysql://localhost/cart", "root", "");
		} catch (SQLException e) {
			System.out.println("koneksi gagal");
		}
		
		try (Statement stmt = connection.createStatement();
				
				ResultSet rs = stmt.executeQuery("SELECT * FROM carts")) {
			
			    while (rs.next()) {
			    	
			        String uid = rs.getString("userID");
			        String proid = rs.getString("productID");
			        int qty = Integer.parseInt(rs.getString("qty"));
			       if(cuid2.equals(uid) && pid.equals(proid)) {
			    	   System.out.println("Jumlah nya adalah " + qty);
			    	   return qty;
			       }
			       
			    }
			} catch (SQLException e) {
				System.out.println(e);
		}
		return -1; 
	}
	
	private boolean deleteCart(String cuid2, String pid, int kurang) {
		int qtys = 100000000;
		
		try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/cart", "root", "");
			     Statement stmt = conn.createStatement();
			     ResultSet rs = stmt.executeQuery("SELECT * FROM carts")) {
			    while (rs.next()) {
			    	String uid = rs.getString("userID");
			        String proid = rs.getString("productID");
			        int qty = Integer.parseInt(rs.getString("qty"));
			       if(cuid2.equals(uid) && pid.equals(proid)) {
			    	   qtys = qty;
			       }
			    }
			} catch (SQLException e) {
			    // handle the exception
			}

		int newQty = qtys - kurang;
		if(newQty < 0) {
			return false;
		}

		try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/cart", "root", "");
		        PreparedStatement stmt = conn.prepareStatement("UPDATE carts SET qty = ? WHERE userID = ? and productID = ?")) {
		    stmt.setInt(1, newQty);
		    stmt.setString(2, cuid2);
		    stmt.setString(3, pid);
		    stmt.executeUpdate();
		} catch (SQLException e) {
		    // handle the exception
		}

		return true;
	}

	private Integer checkQty(String text) {
		try {
		    connection = DriverManager.getConnection("jdbc:mysql://localhost/cart", "root", "");
		} catch (SQLException e) {
			System.out.println("koneksi gagal");
		}
		
		try (Statement stmt = connection.createStatement();
				ResultSet rs = stmt.executeQuery("SELECT * FROM products")) {
			    while (rs.next()) {
			        String column1 = rs.getString("id");
			        int qty = Integer.parseInt(rs.getString("stock"));
			        if(text.equals(column1)) {
			        	return qty;
			        }
			    }
			} catch (SQLException e) {
		}
		return -1;
	}

	public boolean testEmail(String a) {
		boolean check = false;
		
		if(a.charAt(0) == '@') {
			return true;
		} else if(!a.endsWith("@gmail.com")) {
			return true;
		} else if(checkEmail(a)) {
			return true;
		}
		return check;
	}
	
	public boolean checkEmail(String a) {
		try {
		    connection = DriverManager.getConnection("jdbc:mysql://localhost/cart", "root", "");
		} catch (SQLException e) {
			System.out.println("koneksi gagal");
		}
		
		try (Statement stmt = connection.createStatement();
				ResultSet rs = stmt.executeQuery("SELECT * FROM users")) {
			    while (rs.next()) {
			        String column1 = rs.getString("email");
			        if(a.equals(column1)) {
			        	return true;
			        }
			    }
			} catch (SQLException e) {
		}
		return false;
	}

	public boolean inserdata(String sql) {
		try {
		    connection = DriverManager.getConnection("jdbc:mysql://localhost/cart", "root", "");
		} catch (SQLException e) {
			System.out.println("koneksi gagal");
		}
		
		try (Statement stmt = connection.createStatement();
				) {
			stmt.executeUpdate(sql);
			} catch (SQLException e) {
				System.out.print(e);
				return true;
		}
		
		return false;
	}
	
	public void deleteProduct(String id) {
		  try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/cart", "root", "");
		        PreparedStatement stmt = conn.prepareStatement("DELETE FROM products WHERE id = ?")) {
		    stmt.setString(1, id);
		    stmt.executeUpdate();
		  } catch (SQLException e) {
		    // handle the exception
			  System.out.print("Cannot delete data");
		  }
		}

	
	public String idGen() {
		Random randI = new Random();
		String id = "U";
		id +=randI.nextInt(10);
		id +=randI.nextInt(10);
		id +=randI.nextInt(10);
		id +=randI.nextInt(10);
		
        while(checkId(id)) {
        	id = "U";
    		id +=randI.nextInt(10);
    		id +=randI.nextInt(10);
    		id +=randI.nextInt(10);
    		id +=randI.nextInt(10);
        }
        
        return id;
	}
	
	public String idGenProduct() {
		Random randI = new Random();
		String id = "";
		int letterIndex = randI.nextInt(26); 
		id += (char)('A' + letterIndex);
		id +=randI.nextInt(10);
		id +=randI.nextInt(10);
		id +=randI.nextInt(10);
		id +=randI.nextInt(10);
		
        while(checkProductId(id)) {
        	letterIndex = randI.nextInt(26); 
    		id += (char)('A' + letterIndex);
    		id +=randI.nextInt(10);
    		id +=randI.nextInt(10);
    		id +=randI.nextInt(10);
    		id +=randI.nextInt(10);
    		id +=randI.nextInt(10);
        }
   
        return id;
	}
	
	public boolean checkId(String id) {
		try {
		    connection = DriverManager.getConnection("jdbc:mysql://localhost/cart", "root", "");
		} catch (SQLException e) {
			System.out.println("koneksi gagal");
		}
		
		try (Statement stmt = connection.createStatement();
				ResultSet rs = stmt.executeQuery("SELECT * FROM users")) {
			    while (rs.next()) {
			        String column1 = rs.getString("id");
			        if(id.equals(column1)) {
			        	return true;
			        }
			    }
			} catch (SQLException e) {
		}
		return false;
	}
	
	public boolean checkProductId(String id) {
		try {
		    connection = DriverManager.getConnection("jdbc:mysql://localhost/cart", "root", "");
		} catch (SQLException e) {
			System.out.println("koneksi gagal");
		}
		
		try (Statement stmt = connection.createStatement();
				ResultSet rs = stmt.executeQuery("SELECT * FROM products")) {
			    while (rs.next()) {
			        String column1 = rs.getString("id");
			        if(id.equals(column1)) {
			        	return true;
			        }
			    }
			} catch (SQLException e) {
		}
		return false;
	}
	
	public void refreshTable() {
		table.getItems().clear();
		tables.getItems().clear();
		try {
		    connection = DriverManager.getConnection("jdbc:mysql://localhost/cart", "root", "");
		} catch (SQLException e) {
			System.out.println("koneksi gagal");
		}
		data =FXCollections.observableArrayList();
		try (Statement stmt = connection.createStatement();
				ResultSet rs = stmt.executeQuery("SELECT * FROM products")) {
			    while (rs.next()) {
			        String id = rs.getString("id");
			        String type = rs.getString("type");
			        String brand = rs.getString("brand");
			        String price = rs.getString("price");
			        String stock = rs.getString("stock");
			        
			        data.add(new Product(id, type, brand, price, stock));
			    }
			    table.setItems(data);
			    tables.setItems(data);
			} catch (SQLException e) {
		}
	}
	public void refreshTablex(String uid) {
		tablex.getItems().clear();
		try {
		    connection = DriverManager.getConnection("jdbc:mysql://localhost/cart", "root", "");
		} catch (SQLException e) {
			System.out.println("koneksi gagal");
		}
		data =FXCollections.observableArrayList();
		try (Statement stmt = connection.createStatement();
				ResultSet rs = stmt.executeQuery("SELECT * FROM `products` join carts where products.id = carts.productID and carts.userID = '"+uid+"'")) {
			    while (rs.next()) {
			        String pid = rs.getString("productID");
			        String qty = rs.getString("qty");
			        String brand = rs.getString("brand");
			        String price = rs.getString("price");
			        
			        int total = Integer.parseInt(rs.getString("qty")) * Integer.parseInt(rs.getString("price")); 
			        items.add(new InCart(pid, brand, qty, price, "" + total));
			    }
			    tablex.setItems(items);
			    
			} catch (SQLException e) {
		}
	}
	
	public int getTotal(String uid) {
		int gtotal = 0;
		try {
		    connection = DriverManager.getConnection("jdbc:mysql://localhost/cart", "root", "");
		} catch (SQLException e) {
			System.out.println("koneksi gagal");
		}
		data =FXCollections.observableArrayList();
		try (Statement stmt = connection.createStatement();
				ResultSet rs = stmt.executeQuery("SELECT * FROM `products` join carts where products.id = carts.productID and carts.userID = '"+uid+"'")) {
			    while (rs.next()) {

			        
			        gtotal += Integer.parseInt(rs.getString("qty")) * Integer.parseInt(rs.getString("price")); 
			    }
			} catch (SQLException e) {
		}
		return gtotal;
	}
}
