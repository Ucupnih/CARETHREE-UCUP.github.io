package application;

public class InCart {
	private String id;
	private String brand;
	private String qty;
	private String price;
	private String total;
	public InCart(String id, String brand, String qty, String price, String total) {
	    this.id = id;
	    this.brand = brand;
	    this.qty = qty;
	    this.price = price;
	    this.total = total;
	}

	public String getId() {
	    return id;
	}

	public void setId(String id) {
	    this.id = id;
	}

	public String getBrand() {
	    return brand;
	}

	public void setBrand(String brand) {
	    this.brand = brand;
	}

	public String getQty() {
	    return qty;
	}

	public void setQty(String qty) {
	    this.qty = qty;
	}

	public String getPrice() {
	    return price;
	}

	public void setPrice(String price) {
	    this.price = price;
	}

	public String getTotal() {
	    return total;
	}

	public void setTotal(String total) {
	    this.total = total;
	}
}
