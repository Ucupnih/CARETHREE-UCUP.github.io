package application;
	

import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;


public class Register extends Application {
	
	Stage window;
	public static void main(String[] args) {
		launch(args);
	}
	 
	@Override
	public void start(Stage primaryStage) {
		window = primaryStage;
		window.setTitle("Login ");
		GridPane grid = new GridPane();
		grid.setPadding(new Insets(10,10,10,10));
		grid.setVgap(8);
		grid.setHgap(8);
		
		
		Label nameLabel = new Label("Name");
		TextField nameInput= new TextField("");
		nameInput.setPromptText("Name");
		Label usernameLabel = new Label("Username");
		TextField usernameInput= new TextField("");
		usernameInput.setPromptText("Username");
		Label passLabel = new Label("Password");
		TextField passInput= new TextField("");
		passInput.setPromptText("Confirm Password");
		Label cpassLabel = new Label("Confirm Password");
		TextField cpassInput= new TextField("");
		cpassInput.setPromptText("Confirm Password");
		Label emailLabel = new Label("Email");
		TextField emailInput= new TextField("");
		emailInput.setPromptText("xxxxxx@gmail.com");
		Label phoneLabel = new Label("Phone Number");
		TextField phoneInput= new TextField("");
		phoneInput.setPromptText("+62XXXXXXXXX ");
		Label genderLabel = new Label("Gender");
		//Button
		Button loginButton = new Button("Login");
		Button registerButton = new Button("Register");
		
		loginButton.setOnAction(e -> {
			if(2 == 2) {
				Alert.display("Warning", "Name cannot be empty");
			}
		});
		
		
		grid.setConstraints(nameLabel, 0, 0);
		grid.setConstraints(nameInput, 0, 1);
		grid.setConstraints(usernameLabel, 0, 2);
		grid.setConstraints(usernameInput, 0, 3);
		grid.setConstraints(passLabel, 0, 4);
		grid.setConstraints(passInput, 0, 5);
		grid.setConstraints(cpassLabel, 0, 6);
		grid.setConstraints(cpassInput, 0, 7);
		grid.setConstraints(emailLabel, 0, 8);
		grid.setConstraints(emailInput, 0, 9);
		grid.setConstraints(phoneLabel, 0, 10);
		grid.setConstraints(phoneInput, 0, 11);
		grid.setConstraints(genderLabel, 0, 12);
		grid.setConstraints(loginButton, 0, 13);
		grid.setConstraints(registerButton, 1, 13);
		
		
		//menambahkan semua
		grid.getChildren().addAll(nameLabel,nameInput,usernameLabel,usernameInput,passLabel,passInput,cpassLabel, cpassInput,emailLabel, emailInput, phoneLabel,
				phoneInput, genderLabel, loginButton, registerButton);
		Scene scene = new Scene(grid, 300, 450);
		window.setScene(scene);
		window.show();
	}


}
