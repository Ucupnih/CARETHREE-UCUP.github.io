package application;

import javafx.beans.property.SimpleStringProperty;

public class Product {

    private final SimpleStringProperty id;
    private final SimpleStringProperty type;
    private final SimpleStringProperty brand;
    private final SimpleStringProperty price;
    private final SimpleStringProperty stock;

    Product(String id, String type, String brand, String price, String stock) {
        this.id = new SimpleStringProperty(id);
        this.type = new SimpleStringProperty(type);
        this.brand = new SimpleStringProperty(brand);
        this.price = new SimpleStringProperty(price);
        this.stock = new SimpleStringProperty(stock);
    }
    public String getId() {
    return id.get();
    }
    public void setId(String id) {
        this.id.set(id);
    }

    public String getType() {
        return type.get();
    }

    public void setType(String type) {
        this.type.set(type);
    }

    public String getBrand() {
        return brand.get();
    }

    public void setBrand(String brand) {
        this.brand.set(brand);
    }

    public String getPrice() {
        return price.get();
    }

    public void setPrice(String price) {
        this.price.set(price);
    }

    public String getStock() {
        return stock.get();
    }

    public void setStock(String stock) {
        this.stock.set(stock);
    }
}